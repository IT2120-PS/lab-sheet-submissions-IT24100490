# Set your working directory to where the 'Exercise.txt' file is located
setwd("C:\\Users\\IT24100490\\Desktop\\IT24100490")

# Read the 'Exercise.txt' file into a data frame
branch_data <- read.table("Exercise.txt", header = TRUE, sep = "\t")

# View the first few rows of the data to ensure it's loaded correctly
head(branch_data)


str(branch_data)


# Create a boxplot for the 'Sales' variable
boxplot(branch_data$Sales, main = "Boxplot of Sales", ylab = "Sales", col = "lightblue")

# Interpret the shape of the distribution
# Look for outliers, symmetry, and the median line's position.


# Function to find outliers in a numeric vector
find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_value <- IQR(x)
  lower_bound <- Q1 - 1.5 * IQR_value
  upper_bound <- Q3 + 1.5 * IQR_value
  
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}

# Check for outliers in the 'Years' variable
years_outliers <- find_outliers(branch_data$Years)

# Print the outliers
print(years_outliers)


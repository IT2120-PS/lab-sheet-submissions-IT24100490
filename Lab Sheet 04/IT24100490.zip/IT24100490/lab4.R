setwd("C:\\Users\\IT24100490\\Desktop\\IT24100490")
data <- read.table("DATA 4.txt", header=TRUE, sep=" ")
fix(data)
attach(data)

# Part 2
# Part (a)
# Obtaining Box Plots
boxplot(X1, main="Box plot for Team Attendance", outline=TRUE, outpch=8, horizontal=TRUE)
boxplot(X2, main="Box plot for Team Salary", outline=TRUE, outpch=8, horizontal=TRUE)
boxplot(X3, main="Box plot for Years", outline=TRUE, outpch=8, horizontal=TRUE)

# Obtaining Histogram
hist(X1, ylab="Frequency", xlab="Team Attendance", main="Histogram for Team Attendance")
hist(X2, ylab="Frequency", xlab="Team Salary", main="Histogram for Team Salary")
hist(X3, ylab="Frequency", xlab="Years", main="Histogram for Years")

# Stem & Leaf Plot
stem(X1)
stem(X2)
stem(X3)


##Part (b)
##Mean
mean(X1)
mean(X2)
mean(X3)

##Median
median(X1)
median(X2)
median(X3)

##Standard Devaiation
sd(X1)
sd(X2)
sd(X3)

##Part (d)
##oibtaining Inter Quartile Range (IQR) of each variable
IQR(X1)
IQR(X2)
IQR(X3)

##Part 3
##Function to get the mode of a data set
get.mode<-function(y){
  counts<-table(X3)
  names(counts[counts==max(counts)])
}

get.mode(X3)
table(X3)
max(count)
counts==max(counts)
counts[counts==max(counts)]
names(counts[counts==max(counts)])

##Part4 
##Function to check the existence of outliers of a data set
get.outliers<-function(z){
  q1<- quantile(z)[2]
  q3<- quantile(z)[4]
  iqr<- q3 - q1
  
  ub <- q3 = 1.5*iqr
  1b<- q1 v- 1.5*iqr
  
  print(paste("Upper bound=", ub))
  print(paste("Lower bound=", 1b))
  print(paste("Outliers:", paste(sort(z[z,1b | z,ub]),collapse = ",")))
  
  
}

